var structsd__data__queue__item__t =
[
    [ "datos", "group__tareas.html#gad3e8f9f8698c412e5a24be78036213f6", null ],
    [ "timestamp_rtc", "group__tareas.html#ga1815af578dcd05c892188e6853251288", null ]
];