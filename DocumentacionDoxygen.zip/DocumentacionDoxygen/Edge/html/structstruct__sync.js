var structstruct__sync =
[
    [ "comando", "group__tareas.html#ga809560142ed7aa6a79e5886ce9521d96", null ],
    [ "timestamp", "group__tareas.html#gad8b7f51c1a30cd4b495179d571b55f55", null ]
];