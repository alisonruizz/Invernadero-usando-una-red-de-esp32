var group__funciones__envio =
[
    [ "enviarComandoActuador", "group__funciones__envio.html#gaa98547a5ced5ace26c5347f2567f264f", null ],
    [ "enviarDatosRTC", "group__funciones__envio.html#ga5a4034ac06db9c39787de3e0aa7a03d9", null ]
];