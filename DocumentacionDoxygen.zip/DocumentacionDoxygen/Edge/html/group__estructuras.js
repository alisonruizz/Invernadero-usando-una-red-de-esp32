var group__estructuras =
[
    [ "struct_message", "structstruct__message.html", [
      [ "hum_dht", "group__tareas.html#ga2919b624af545c794de8344f4504b9d6", null ],
      [ "luz", "group__tareas.html#ga9934d492fab2beb91f3704b7b66859f3", null ],
      [ "temp_dht", "group__tareas.html#ga44b6ae2ced7188b50d401049b6fc55cb", null ],
      [ "temp_ds18b20", "group__tareas.html#gad4d8b522e6064228f6f1ebcb659075d2", null ]
    ] ],
    [ "struct_rtc", "structstruct__rtc.html", [
      [ "hora", "group__tareas.html#gaeea0f315d51983c1da3a91f9cbd7379d", null ]
    ] ],
    [ "struct_sync", "structstruct__sync.html", [
      [ "comando", "group__tareas.html#ga809560142ed7aa6a79e5886ce9521d96", null ],
      [ "timestamp", "group__tareas.html#gad8b7f51c1a30cd4b495179d571b55f55", null ]
    ] ],
    [ "struct_actuador", "structstruct__actuador.html", [
      [ "comando", "group__tareas.html#ga9539e74aa5f87df5e313a7e752b9a6bb", null ],
      [ "temperatura", "group__tareas.html#gac1b53f685e13112e8667bc1340ebae33", null ]
    ] ],
    [ "sensor_data_queue_item_t", "structsensor__data__queue__item__t.html", [
      [ "datos", "group__tareas.html#ga6bd9b8422eb6fa822ab265208add5d2e", null ],
      [ "timestamp", "group__tareas.html#gaa4f96c51772fbe3478e43c3dfe41415b", null ]
    ] ],
    [ "telegram_queue_item_t", "structtelegram__queue__item__t.html", [
      [ "mensaje", "group__tareas.html#ga13ac4da8a4e89c1d691baea166e27e02", null ]
    ] ],
    [ "sd_data_queue_item_t", "structsd__data__queue__item__t.html", [
      [ "datos", "group__tareas.html#gad3e8f9f8698c412e5a24be78036213f6", null ],
      [ "timestamp_rtc", "group__tareas.html#ga1815af578dcd05c892188e6853251288", null ]
    ] ]
];