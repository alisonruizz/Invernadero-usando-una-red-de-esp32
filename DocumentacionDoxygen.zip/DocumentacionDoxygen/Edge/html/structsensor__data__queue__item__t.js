var structsensor__data__queue__item__t =
[
    [ "datos", "group__tareas.html#ga6bd9b8422eb6fa822ab265208add5d2e", null ],
    [ "timestamp", "group__tareas.html#gaa4f96c51772fbe3478e43c3dfe41415b", null ]
];