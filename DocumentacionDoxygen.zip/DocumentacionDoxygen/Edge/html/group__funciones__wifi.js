var group__funciones__wifi =
[
    [ "cambiarCanal", "group__funciones__wifi.html#ga98edbbce404c61b19466ed33a9841e26", null ]
];