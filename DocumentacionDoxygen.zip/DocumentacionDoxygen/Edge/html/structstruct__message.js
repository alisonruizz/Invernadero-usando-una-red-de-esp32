var structstruct__message =
[
    [ "hum_dht", "group__tareas.html#ga2919b624af545c794de8344f4504b9d6", null ],
    [ "luz", "group__tareas.html#ga9934d492fab2beb91f3704b7b66859f3", null ],
    [ "temp_dht", "group__tareas.html#ga44b6ae2ced7188b50d401049b6fc55cb", null ],
    [ "temp_ds18b20", "group__tareas.html#gad4d8b522e6064228f6f1ebcb659075d2", null ]
];