var structstruct__rtc =
[
    [ "hora", "group__tareas.html#gaeea0f315d51983c1da3a91f9cbd7379d", null ]
];