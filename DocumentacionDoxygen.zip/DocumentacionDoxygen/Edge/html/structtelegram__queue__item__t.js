var structtelegram__queue__item__t =
[
    [ "mensaje", "group__tareas.html#ga13ac4da8a4e89c1d691baea166e27e02", null ]
];