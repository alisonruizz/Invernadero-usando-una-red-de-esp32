var topics =
[
    [ "Includes", "group__includes.html", null ],
    [ "Definiciones", "group__defines.html", "group__defines" ],
    [ "Estructuras de datos", "group__estructuras.html", "group__estructuras" ],
    [ "Variables globales", "group__variables.html", "group__variables" ],
    [ "Funciones de manejo de SD", "group__funciones__sd.html", "group__funciones__sd" ],
    [ "Funciones de manejo WiFi", "group__funciones__wifi.html", "group__funciones__wifi" ],
    [ "Funciones ESP-NOW", "group__funciones__espnow.html", "group__funciones__espnow" ],
    [ "Callbacks de Timers", "group__funciones__timer.html", "group__funciones__timer" ],
    [ "Funciones de Envío", "group__funciones__envio.html", "group__funciones__envio" ],
    [ "Tareas FreeRTOS", "group__tareas.html", "group__tareas" ]
];