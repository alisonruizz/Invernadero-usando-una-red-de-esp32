var annotated_dup =
[
    [ "sd_data_queue_item_t", "structsd__data__queue__item__t.html", "structsd__data__queue__item__t" ],
    [ "sensor_data_queue_item_t", "structsensor__data__queue__item__t.html", "structsensor__data__queue__item__t" ],
    [ "struct_actuador", "structstruct__actuador.html", "structstruct__actuador" ],
    [ "struct_message", "structstruct__message.html", "structstruct__message" ],
    [ "struct_rtc", "structstruct__rtc.html", "structstruct__rtc" ],
    [ "struct_sync", "structstruct__sync.html", "structstruct__sync" ],
    [ "telegram_queue_item_t", "structtelegram__queue__item__t.html", "structtelegram__queue__item__t" ]
];