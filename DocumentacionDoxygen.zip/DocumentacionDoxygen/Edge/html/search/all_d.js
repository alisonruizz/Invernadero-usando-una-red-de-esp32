var searchData=
[
  ['rtc_0',['rtc',['../codigoedge__documentado_8ino.html#afa042f998806fcdedab1794cebbeaad3',1,'codigoedge_documentado.ino']]]
];
