var searchData=
[
  ['luz_0',['luz',['../group__tareas.html#ga9934d492fab2beb91f3704b7b66859f3',1,'struct_message']]]
];
