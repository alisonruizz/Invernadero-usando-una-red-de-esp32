var searchData=
[
  ['tareas_20freertos_0',['Tareas FreeRTOS',['../group__tareas.html',1,'']]],
  ['telegram_5fqueue_5fitem_5ft_1',['telegram_queue_item_t',['../structtelegram__queue__item__t.html',1,'']]],
  ['temp_5fdht_2',['temp_dht',['../group__tareas.html#ga44b6ae2ced7188b50d401049b6fc55cb',1,'struct_message']]],
  ['temp_5fds18b20_3',['temp_ds18b20',['../group__tareas.html#gad4d8b522e6064228f6f1ebcb659075d2',1,'struct_message']]],
  ['temperatura_4',['temperatura',['../group__tareas.html#gac1b53f685e13112e8667bc1340ebae33',1,'struct_actuador']]],
  ['tiempo_5fdespierto_5fticks_5',['TIEMPO_DESPIERTO_TICKS',['../group__defines.html#ga0d107d891ba16b9bcb6aa237d3115481',1,'codigoedge_documentado.ino']]],
  ['tiempo_5fdormido_5fticks_6',['TIEMPO_DORMIDO_TICKS',['../group__defines.html#gab5122f75f75b13cc1dda7bc8038a329c',1,'codigoedge_documentado.ino']]],
  ['timers_7',['Callbacks de Timers',['../group__funciones__timer.html',1,'']]],
  ['timestamp_8',['timestamp',['../group__tareas.html#gad8b7f51c1a30cd4b495179d571b55f55',1,'struct_sync::timestamp'],['../group__tareas.html#gaa4f96c51772fbe3478e43c3dfe41415b',1,'sensor_data_queue_item_t::timestamp']]],
  ['timestamp_5frtc_9',['timestamp_rtc',['../group__tareas.html#ga1815af578dcd05c892188e6853251288',1,'sd_data_queue_item_t']]]
];
