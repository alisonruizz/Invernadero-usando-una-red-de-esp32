var searchData=
[
  ['bot_0',['bot',['../codigoedge__documentado_8ino.html#a7ce3e4decbd435e24d531147dcd29c15',1,'codigoedge_documentado.ino']]]
];
