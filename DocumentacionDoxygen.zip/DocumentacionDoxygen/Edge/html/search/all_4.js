var searchData=
[
  ['fecha_5factual_0',['fecha_actual',['../group__variables.html#ga576643a6f1fb2b2d34f1d2613fe491e9',1,'codigoedge_documentado.ino']]],
  ['freertos_1',['FreeRTOS',['../group___tareas.html',1,'FreeRTOS'],['../group__tareas.html',1,'Tareas FreeRTOS']]],
  ['funciones_20de_20envío_2',['Funciones de Envío',['../group__funciones__envio.html',1,'']]],
  ['funciones_20de_20manejo_20de_20sd_3',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['funciones_20de_20manejo_20wifi_4',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]],
  ['funciones_20esp_20now_5',['Funciones ESP-NOW',['../group__funciones__espnow.html',1,'']]],
  ['funciones_20principales_6',['Funciones Principales',['../group__main__func.html',1,'']]]
];
