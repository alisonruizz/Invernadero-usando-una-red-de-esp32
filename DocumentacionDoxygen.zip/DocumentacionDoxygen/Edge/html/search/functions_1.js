var searchData=
[
  ['cambiarcanal_0',['cambiarCanal',['../group__funciones__wifi.html#ga98edbbce404c61b19466ed33a9841e26',1,'codigoedge_documentado.ino']]],
  ['crearcarpetadiaria_1',['crearCarpetaDiaria',['../group__funciones__sd.html#gaeeecb3717ac6a0914da2c188302bd5ef',1,'codigoedge_documentado.ino']]]
];
