var searchData=
[
  ['enviarcomandoactuador_0',['enviarComandoActuador',['../group__funciones__envio.html#gaa98547a5ced5ace26c5347f2567f264f',1,'codigoedge_documentado.ino']]],
  ['enviarcomandosincronizacion_1',['enviarComandoSincronizacion',['../group__funciones__espnow.html#ga33d9e23327f46b073838cc8d2cf502b0',1,'codigoedge_documentado.ino']]],
  ['enviardatosrtc_2',['enviarDatosRTC',['../group__funciones__envio.html#ga5a4034ac06db9c39787de3e0aa7a03d9',1,'codigoedge_documentado.ino']]]
];
