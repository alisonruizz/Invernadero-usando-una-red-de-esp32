var searchData=
[
  ['xeventgroup_0',['xEventGroup',['../group__variables.html#ga23235b0baa8a2582eb7db3a681345615',1,'codigoedge_documentado.ino']]],
  ['xmutexespnow_1',['xMutexESPNOW',['../group__variables.html#ga9c2ef796abdc0e379eaede1b9aba94b9',1,'codigoedge_documentado.ino']]],
  ['xmutexsd_2',['xMutexSD',['../group__variables.html#ga15023d762c93c270b27aec62e10920b3',1,'codigoedge_documentado.ino']]],
  ['xmutexwifi_3',['xMutexWiFi',['../group__variables.html#ga02e17b191aa8145677080b1db4e8c224',1,'codigoedge_documentado.ino']]],
  ['xqueuesd_4',['xQueueSD',['../group__variables.html#ga87dfbd72fd58cb98682717cde2fa17eb',1,'codigoedge_documentado.ino']]],
  ['xqueuesensordata_5',['xQueueSensorData',['../group__variables.html#ga62dbf4898ac5cd03a4bb1d7c438f248a',1,'codigoedge_documentado.ino']]],
  ['xqueuetelegram_6',['xQueueTelegram',['../group__variables.html#ga7b1d22b5f99fb91a1465b28a7aed2f84',1,'codigoedge_documentado.ino']]],
  ['xtaskespnow_7',['xTaskESPNOW',['../group__variables.html#gae94aa1eedf03827f2c69b5d9318ccb7d',1,'codigoedge_documentado.ino']]],
  ['xtaskrtc_8',['xTaskRTC',['../group__variables.html#ga9f8ea3e25b30d08dd33a5606e1205019',1,'codigoedge_documentado.ino']]],
  ['xtasksd_9',['xTaskSD',['../group__variables.html#ga3850ccb74696470f818c6066e8f62cc7',1,'codigoedge_documentado.ino']]],
  ['xtasksleepmanager_10',['xTaskSleepManager',['../group__variables.html#ga499fb614721b3f6d87ae9826ce538fbf',1,'codigoedge_documentado.ino']]],
  ['xtasktelegram_11',['xTaskTelegram',['../group__variables.html#ga6da5be20230d1b8d27ee7fb18fa07bf2',1,'codigoedge_documentado.ino']]],
  ['xtimerrtcenvio_12',['xTimerRTCEnvio',['../group__variables.html#gadf3c0e98294b8c21120cac9bcb0faefa',1,'codigoedge_documentado.ino']]],
  ['xtimersistemaactivo_13',['xTimerSistemaActivo',['../group__variables.html#ga92b0d60d30e9c0184c361436edd6137d',1,'codigoedge_documentado.ino']]]
];
