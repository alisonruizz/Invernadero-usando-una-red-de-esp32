var searchData=
[
  ['secured_5fclient_0',['secured_client',['../codigoedge__documentado_8ino.html#ad3a6b16b90a71ff014f988449b7ecd4e',1,'codigoedge_documentado.ino']]],
  ['sistema_5factivo_1',['sistema_activo',['../group__variables.html#gaf1d8756a5b98eb242a0a088a6010e9c8',1,'codigoedge_documentado.ino']]],
  ['ssid_2',['ssid',['../group__variables.html#ga587ba0cb07f02913598610049a3bbb79',1,'codigoedge_documentado.ino']]]
];
