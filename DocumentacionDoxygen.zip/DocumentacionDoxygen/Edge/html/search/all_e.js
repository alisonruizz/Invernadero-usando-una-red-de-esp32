var searchData=
[
  ['sd_0',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['sd_5fcs_5fpin_1',['SD_CS_PIN',['../group__defines.html#ga04d57a6c18b2d5e81f31093e58ed0c62',1,'codigoedge_documentado.ino']]],
  ['sd_5fdata_5fqueue_5fitem_5ft_2',['sd_data_queue_item_t',['../structsd__data__queue__item__t.html',1,'']]],
  ['sd_5fmiso_5fpin_3',['SD_MISO_PIN',['../group__defines.html#gad3aea67d9c7c7dc0be847a1467786abb',1,'codigoedge_documentado.ino']]],
  ['sd_5fmosi_5fpin_4',['SD_MOSI_PIN',['../group__defines.html#ga1150cf94392cb54e7e979e6b69f210fb',1,'codigoedge_documentado.ino']]],
  ['sd_5fsck_5fpin_5',['SD_SCK_PIN',['../group__defines.html#ga712b6e5405cc83d1a7c1a30f198df12a',1,'codigoedge_documentado.ino']]],
  ['secured_5fclient_6',['secured_client',['../codigoedge__documentado_8ino.html#ad3a6b16b90a71ff014f988449b7ecd4e',1,'codigoedge_documentado.ino']]],
  ['sensor_5fdata_5fqueue_5fitem_5ft_7',['sensor_data_queue_item_t',['../structsensor__data__queue__item__t.html',1,'']]],
  ['setup_8',['setup',['../group__main__func.html#ga4fc01d736fe50cf5b977f755b675f11d',1,'codigoedge_documentado.ino']]],
  ['sistema_5factivo_9',['sistema_activo',['../group__variables.html#gaf1d8756a5b98eb242a0a088a6010e9c8',1,'codigoedge_documentado.ino']]],
  ['ssid_10',['ssid',['../group__variables.html#ga587ba0cb07f02913598610049a3bbb79',1,'codigoedge_documentado.ino']]],
  ['stack_5fsize_5fesp_5fnow_11',['STACK_SIZE_ESP_NOW',['../group__defines.html#ga8a9e4fec0fe48a219932e5ea4e8c5e4f',1,'codigoedge_documentado.ino']]],
  ['stack_5fsize_5frtc_12',['STACK_SIZE_RTC',['../group__defines.html#gabb2cb03389c9557bfe75e0d5c43dd808',1,'codigoedge_documentado.ino']]],
  ['stack_5fsize_5fsd_13',['STACK_SIZE_SD',['../group__defines.html#ga706a564be4956e600577c3a149323e0f',1,'codigoedge_documentado.ino']]],
  ['stack_5fsize_5fsleep_5fmanager_14',['STACK_SIZE_SLEEP_MANAGER',['../group__defines.html#ga0d793d5ff83b8ae1dfd618740998c344',1,'codigoedge_documentado.ino']]],
  ['stack_5fsize_5ftelegram_15',['STACK_SIZE_TELEGRAM',['../group__defines.html#gab7af03a5e75c6d5987c8d1914324b0d9',1,'codigoedge_documentado.ino']]],
  ['struct_5factuador_16',['struct_actuador',['../structstruct__actuador.html',1,'']]],
  ['struct_5fmessage_17',['struct_message',['../structstruct__message.html',1,'']]],
  ['struct_5frtc_18',['struct_rtc',['../structstruct__rtc.html',1,'']]],
  ['struct_5fsync_19',['struct_sync',['../structstruct__sync.html',1,'']]]
];
