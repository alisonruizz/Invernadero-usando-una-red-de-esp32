var searchData=
[
  ['includes_0',['Includes',['../group__includes.html',1,'']]],
  ['inicializarespnow_1',['inicializarESPNOW',['../group__funciones__espnow.html#gae618d122b2318b27d35948cec3839f2d',1,'codigoedge_documentado.ino']]],
  ['inicializarsd_2',['inicializarSD',['../codigoedge__documentado_8ino.html#a52d3e85457d1478c1c6eaac49236f5d9',1,'codigoedge_documentado.ino']]]
];
