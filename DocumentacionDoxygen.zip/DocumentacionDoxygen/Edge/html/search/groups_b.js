var searchData=
[
  ['variables_20globales_0',['Variables globales',['../group__variables.html',1,'']]]
];
