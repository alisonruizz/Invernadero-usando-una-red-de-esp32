var searchData=
[
  ['mac1_0',['mac1',['../group__variables.html#gaba0b34d83efb865c486a93849574d437',1,'codigoedge_documentado.ino']]],
  ['mac2_1',['mac2',['../group__variables.html#gae42bea84a44cb55e7dc54b119c9376e2',1,'codigoedge_documentado.ino']]],
  ['mensaje_2',['mensaje',['../group__tareas.html#ga13ac4da8a4e89c1d691baea166e27e02',1,'telegram_queue_item_t']]]
];
