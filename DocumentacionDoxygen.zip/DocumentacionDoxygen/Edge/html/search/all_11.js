var searchData=
[
  ['variables_20globales_0',['Variables globales',['../group__variables.html',1,'']]],
  ['vtaskespnowhandler_1',['vTaskESPNOWHandler',['../group__tareas.html#ga0f685b93059294881eb041fe90bdc64d',1,'codigoedge_documentado.ino']]],
  ['vtaskrtchandler_2',['vTaskRTCHandler',['../group__tareas.html#ga6f2fc4339406088e83f9fdecc02cdcb9',1,'codigoedge_documentado.ino']]],
  ['vtasksdhandler_3',['vTaskSDHandler',['../group__tareas.html#gad7a4099b7dfb7d4be5825ed167eee64d',1,'codigoedge_documentado.ino']]],
  ['vtasksleepmanager_4',['vTaskSleepManager',['../group___tareas.html#ga037292a7783146e25a2cd73b729ad658',1,'codigoedge_documentado.ino']]],
  ['vtasktelegramhandler_5',['vTaskTelegramHandler',['../group___tareas.html#gab36e68f65275da880ec38864663dadb9',1,'codigoedge_documentado.ino']]],
  ['vtimerrtccallback_6',['vTimerRTCCallback',['../group__funciones__timer.html#gad33ed93210a4159478c3e2725bb67af2',1,'codigoedge_documentado.ino']]],
  ['vtimersistemaactivocallback_7',['vTimerSistemaActivoCallback',['../group__funciones__timer.html#gaf978668233e008008442216fb540f883',1,'codigoedge_documentado.ino']]]
];
