var searchData=
[
  ['principales_0',['Funciones Principales',['../group__main__func.html',1,'']]]
];
