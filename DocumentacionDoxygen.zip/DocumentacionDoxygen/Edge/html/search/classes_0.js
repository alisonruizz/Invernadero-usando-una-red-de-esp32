var searchData=
[
  ['sd_5fdata_5fqueue_5fitem_5ft_0',['sd_data_queue_item_t',['../structsd__data__queue__item__t.html',1,'']]],
  ['sensor_5fdata_5fqueue_5fitem_5ft_1',['sensor_data_queue_item_t',['../structsensor__data__queue__item__t.html',1,'']]],
  ['struct_5factuador_2',['struct_actuador',['../structstruct__actuador.html',1,'']]],
  ['struct_5fmessage_3',['struct_message',['../structstruct__message.html',1,'']]],
  ['struct_5frtc_4',['struct_rtc',['../structstruct__rtc.html',1,'']]],
  ['struct_5fsync_5',['struct_sync',['../structstruct__sync.html',1,'']]]
];
