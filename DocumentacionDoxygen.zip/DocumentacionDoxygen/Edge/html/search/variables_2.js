var searchData=
[
  ['fecha_5factual_0',['fecha_actual',['../group__variables.html#ga576643a6f1fb2b2d34f1d2613fe491e9',1,'codigoedge_documentado.ino']]]
];
