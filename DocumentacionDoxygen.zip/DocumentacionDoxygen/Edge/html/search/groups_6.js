var searchData=
[
  ['manejo_20de_20sd_0',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['manejo_20wifi_1',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]]
];
