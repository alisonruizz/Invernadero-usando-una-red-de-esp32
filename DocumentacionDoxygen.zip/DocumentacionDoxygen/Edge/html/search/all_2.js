var searchData=
[
  ['datos_0',['datos',['../group__tareas.html#ga6bd9b8422eb6fa822ab265208add5d2e',1,'sensor_data_queue_item_t::datos'],['../group__tareas.html#gad3e8f9f8698c412e5a24be78036213f6',1,'sd_data_queue_item_t::datos'],['../group__estructuras.html',1,'Estructuras de datos']]],
  ['datos_5fglobal_1',['datos_global',['../group__variables.html#ga746cc256b2021369bfcd756d50afe45b',1,'codigoedge_documentado.ino']]],
  ['de_20datos_2',['Estructuras de datos',['../group__estructuras.html',1,'']]],
  ['de_20envío_3',['Funciones de Envío',['../group__funciones__envio.html',1,'']]],
  ['de_20manejo_20de_20sd_4',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['de_20manejo_20wifi_5',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]],
  ['de_20sd_6',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['de_20timers_7',['Callbacks de Timers',['../group__funciones__timer.html',1,'']]],
  ['definiciones_8',['Definiciones',['../group__defines.html',1,'']]]
];
