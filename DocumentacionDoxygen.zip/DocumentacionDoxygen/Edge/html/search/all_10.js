var searchData=
[
  ['umbral_5fds18b20_0',['UMBRAL_DS18B20',['../group__defines.html#gaea481bffc7af40e90e862402f7cd584a',1,'codigoedge_documentado.ino']]],
  ['umbral_5fhum_5fdht_1',['UMBRAL_HUM_DHT',['../group__defines.html#gad496c8a303b5ad869d5155c7ce4edc2e',1,'codigoedge_documentado.ino']]],
  ['umbral_5fluz_2',['UMBRAL_LUZ',['../group__defines.html#ga532ab754224e2d897d84f4b61abbb604',1,'codigoedge_documentado.ino']]],
  ['umbral_5ftemp_5fdht_3',['UMBRAL_TEMP_DHT',['../group__defines.html#ga00456ad13f7c65f8bf6d9ebad316509f',1,'codigoedge_documentado.ino']]]
];
