var searchData=
[
  ['temp_5fdht_0',['temp_dht',['../group__tareas.html#ga44b6ae2ced7188b50d401049b6fc55cb',1,'struct_message']]],
  ['temp_5fds18b20_1',['temp_ds18b20',['../group__tareas.html#gad4d8b522e6064228f6f1ebcb659075d2',1,'struct_message']]],
  ['temperatura_2',['temperatura',['../group__tareas.html#gac1b53f685e13112e8667bc1340ebae33',1,'struct_actuador']]],
  ['timestamp_3',['timestamp',['../group__tareas.html#gad8b7f51c1a30cd4b495179d571b55f55',1,'struct_sync::timestamp'],['../group__tareas.html#gaa4f96c51772fbe3478e43c3dfe41415b',1,'sensor_data_queue_item_t::timestamp']]],
  ['timestamp_5frtc_4',['timestamp_rtc',['../group__tareas.html#ga1815af578dcd05c892188e6853251288',1,'sd_data_queue_item_t']]]
];
