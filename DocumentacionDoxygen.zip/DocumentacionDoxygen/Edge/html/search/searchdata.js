var indexSectionsWithContent =
{
  0: "bcdefghilmnoprstuvwx",
  1: "st",
  2: "c",
  3: "bcegiosv",
  4: "cdfhlmprstx",
  5: "cdefgimnpstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Módulos"
};

