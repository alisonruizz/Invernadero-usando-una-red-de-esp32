var searchData=
[
  ['sd_0',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]]
];
