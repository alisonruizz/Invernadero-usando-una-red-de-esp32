var searchData=
[
  ['canal_5fespnow_0',['canal_espnow',['../group__variables.html#ga00f7c148295033c7a13129ab139adb68',1,'codigoedge_documentado.ino']]],
  ['canal_5fwifi_1',['canal_wifi',['../group__variables.html#ga2c20308af2c375fd84d1b9fb3edabbdc',1,'codigoedge_documentado.ino']]],
  ['comando_2',['comando',['../group__tareas.html#ga809560142ed7aa6a79e5886ce9521d96',1,'struct_sync::comando'],['../group__tareas.html#ga9539e74aa5f87df5e313a7e752b9a6bb',1,'struct_actuador::comando']]]
];
