var searchData=
[
  ['wifi_0',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]]
];
