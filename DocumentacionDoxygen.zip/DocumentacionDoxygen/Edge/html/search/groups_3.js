var searchData=
[
  ['freertos_0',['FreeRTOS',['../group___tareas.html',1,'FreeRTOS'],['../group__tareas.html',1,'Tareas FreeRTOS']]],
  ['funciones_20de_20envío_1',['Funciones de Envío',['../group__funciones__envio.html',1,'']]],
  ['funciones_20de_20manejo_20de_20sd_2',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['funciones_20de_20manejo_20wifi_3',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]],
  ['funciones_20esp_20now_4',['Funciones ESP-NOW',['../group__funciones__espnow.html',1,'']]],
  ['funciones_20principales_5',['Funciones Principales',['../group__main__func.html',1,'']]]
];
