var searchData=
[
  ['setup_0',['setup',['../group__main__func.html#ga4fc01d736fe50cf5b977f755b675f11d',1,'codigoedge_documentado.ino']]]
];
