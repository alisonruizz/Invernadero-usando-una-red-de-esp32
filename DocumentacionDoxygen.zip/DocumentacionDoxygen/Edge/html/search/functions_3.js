var searchData=
[
  ['guardardatossd_0',['guardarDatosSD',['../group__funciones__sd.html#gacadaea6e0e360c0c562aded8376e5fca',1,'codigoedge_documentado.ino']]]
];
