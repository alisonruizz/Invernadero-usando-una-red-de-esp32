var searchData=
[
  ['datos_0',['datos',['../group__tareas.html#ga6bd9b8422eb6fa822ab265208add5d2e',1,'sensor_data_queue_item_t::datos'],['../group__tareas.html#gad3e8f9f8698c412e5a24be78036213f6',1,'sd_data_queue_item_t::datos']]],
  ['datos_5fglobal_1',['datos_global',['../group__variables.html#ga746cc256b2021369bfcd756d50afe45b',1,'codigoedge_documentado.ino']]]
];
