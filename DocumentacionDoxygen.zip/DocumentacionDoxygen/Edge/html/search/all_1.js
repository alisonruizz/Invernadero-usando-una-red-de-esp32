var searchData=
[
  ['callbacks_20de_20timers_0',['Callbacks de Timers',['../group__funciones__timer.html',1,'']]],
  ['cambiarcanal_1',['cambiarCanal',['../group__funciones__wifi.html#ga98edbbce404c61b19466ed33a9841e26',1,'codigoedge_documentado.ino']]],
  ['canal_5fespnow_2',['canal_espnow',['../group__variables.html#ga00f7c148295033c7a13129ab139adb68',1,'codigoedge_documentado.ino']]],
  ['canal_5fwifi_3',['canal_wifi',['../group__variables.html#ga2c20308af2c375fd84d1b9fb3edabbdc',1,'codigoedge_documentado.ino']]],
  ['chat_5fid_4',['CHAT_ID',['../group__defines.html#ga46cd8d05b33c73963e3dd6634cbef62e',1,'codigoedge_documentado.ino']]],
  ['codigoedge_5fdocumentado_2eino_5',['codigoedge_documentado.ino',['../codigoedge__documentado_8ino.html',1,'']]],
  ['comando_6',['comando',['../group__tareas.html#ga809560142ed7aa6a79e5886ce9521d96',1,'struct_sync::comando'],['../group__tareas.html#ga9539e74aa5f87df5e313a7e752b9a6bb',1,'struct_actuador::comando']]],
  ['crearcarpetadiaria_7',['crearCarpetaDiaria',['../group__funciones__sd.html#gaeeecb3717ac6a0914da2c188302bd5ef',1,'codigoedge_documentado.ino']]]
];
