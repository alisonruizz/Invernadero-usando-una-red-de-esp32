var searchData=
[
  ['obtenerfechaactual_0',['obtenerFechaActual',['../codigoedge__documentado_8ino.html#ae34955afc3c11075ce0a95115034bdf5',1,'codigoedge_documentado.ino']]],
  ['ondatarecv_1',['OnDataRecv',['../group__funciones__espnow.html#ga7bed38595dc6abdc81699bca332b9608',1,'codigoedge_documentado.ino']]],
  ['ondatasent_2',['OnDataSent',['../group__funciones__espnow.html#ga1ec6b84c5d1247e1390758d6df12d0dc',1,'codigoedge_documentado.ino']]]
];
