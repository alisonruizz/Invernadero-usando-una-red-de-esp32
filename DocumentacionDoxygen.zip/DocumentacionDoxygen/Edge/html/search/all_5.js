var searchData=
[
  ['globales_0',['Variables globales',['../group__variables.html',1,'']]],
  ['guardardatossd_1',['guardarDatosSD',['../group__funciones__sd.html#gacadaea6e0e360c0c562aded8376e5fca',1,'codigoedge_documentado.ino']]]
];
