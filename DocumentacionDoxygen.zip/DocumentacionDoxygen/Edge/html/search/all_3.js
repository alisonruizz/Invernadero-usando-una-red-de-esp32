var searchData=
[
  ['envío_0',['Funciones de Envío',['../group__funciones__envio.html',1,'']]],
  ['enviarcomandoactuador_1',['enviarComandoActuador',['../group__funciones__envio.html#gaa98547a5ced5ace26c5347f2567f264f',1,'codigoedge_documentado.ino']]],
  ['enviarcomandosincronizacion_2',['enviarComandoSincronizacion',['../group__funciones__espnow.html#ga33d9e23327f46b073838cc8d2cf502b0',1,'codigoedge_documentado.ino']]],
  ['enviardatosrtc_3',['enviarDatosRTC',['../group__funciones__envio.html#ga5a4034ac06db9c39787de3e0aa7a03d9',1,'codigoedge_documentado.ino']]],
  ['envio_5fhora_5finterval_5fticks_4',['ENVIO_HORA_INTERVAL_TICKS',['../group__defines.html#gac6af9374a2761b316c037c213cee7dcb',1,'codigoedge_documentado.ino']]],
  ['esp_20now_5',['Funciones ESP-NOW',['../group__funciones__espnow.html',1,'']]],
  ['estructuras_20de_20datos_6',['Estructuras de datos',['../group__estructuras.html',1,'']]]
];
