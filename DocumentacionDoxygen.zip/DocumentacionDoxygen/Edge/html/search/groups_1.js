var searchData=
[
  ['datos_0',['Estructuras de datos',['../group__estructuras.html',1,'']]],
  ['de_20datos_1',['Estructuras de datos',['../group__estructuras.html',1,'']]],
  ['de_20envío_2',['Funciones de Envío',['../group__funciones__envio.html',1,'']]],
  ['de_20manejo_20de_20sd_3',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['de_20manejo_20wifi_4',['Funciones de manejo WiFi',['../group__funciones__wifi.html',1,'']]],
  ['de_20sd_5',['Funciones de manejo de SD',['../group__funciones__sd.html',1,'']]],
  ['de_20timers_6',['Callbacks de Timers',['../group__funciones__timer.html',1,'']]],
  ['definiciones_7',['Definiciones',['../group__defines.html',1,'']]]
];
