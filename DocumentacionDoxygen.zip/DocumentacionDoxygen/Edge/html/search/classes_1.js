var searchData=
[
  ['telegram_5fqueue_5fitem_5ft_0',['telegram_queue_item_t',['../structtelegram__queue__item__t.html',1,'']]]
];
