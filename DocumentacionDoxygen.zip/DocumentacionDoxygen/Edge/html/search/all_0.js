var searchData=
[
  ['bit_5fdatos_5frecibidos_0',['BIT_DATOS_RECIBIDOS',['../group__defines.html#gac7111e38cc3940a8668b3fd35be97d58',1,'codigoedge_documentado.ino']]],
  ['bit_5fdormir_5fsistema_1',['BIT_DORMIR_SISTEMA',['../group__defines.html#gaf94cfa738ae4de0506dd3f08dbc71b7b',1,'codigoedge_documentado.ino']]],
  ['bit_5fenviar_5ftelegram_2',['BIT_ENVIAR_TELEGRAM',['../group__defines.html#ga87dc4b2fa08c986f85c424e74cc14510',1,'codigoedge_documentado.ino']]],
  ['bit_5fguardar_5fsd_3',['BIT_GUARDAR_SD',['../group__defines.html#ga0427b7d36d9f3b6f2213f9ba2119d63f',1,'codigoedge_documentado.ino']]],
  ['bot_4',['bot',['../codigoedge__documentado_8ino.html#a7ce3e4decbd435e24d531147dcd29c15',1,'codigoedge_documentado.ino']]],
  ['bottoken_5',['BOTtoken',['../group__defines.html#gaa5df323e1cdbda5c2c68ac68287d911e',1,'codigoedge_documentado.ino']]]
];
