var group__funciones__espnow =
[
    [ "enviarComandoSincronizacion", "group__funciones__espnow.html#ga33d9e23327f46b073838cc8d2cf502b0", null ],
    [ "inicializarESPNOW", "group__funciones__espnow.html#gae618d122b2318b27d35948cec3839f2d", null ],
    [ "OnDataRecv", "group__funciones__espnow.html#ga7bed38595dc6abdc81699bca332b9608", null ],
    [ "OnDataSent", "group__funciones__espnow.html#ga1ec6b84c5d1247e1390758d6df12d0dc", null ]
];