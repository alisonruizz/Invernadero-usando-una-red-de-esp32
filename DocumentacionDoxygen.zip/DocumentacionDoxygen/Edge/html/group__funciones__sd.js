var group__funciones__sd =
[
    [ "crearCarpetaDiaria", "group__funciones__sd.html#gaeeecb3717ac6a0914da2c188302bd5ef", null ],
    [ "guardarDatosSD", "group__funciones__sd.html#gacadaea6e0e360c0c562aded8376e5fca", null ]
];