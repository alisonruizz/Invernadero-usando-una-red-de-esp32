var structstruct__actuador =
[
    [ "comando", "group__tareas.html#ga9539e74aa5f87df5e313a7e752b9a6bb", null ],
    [ "temperatura", "group__tareas.html#gac1b53f685e13112e8667bc1340ebae33", null ]
];