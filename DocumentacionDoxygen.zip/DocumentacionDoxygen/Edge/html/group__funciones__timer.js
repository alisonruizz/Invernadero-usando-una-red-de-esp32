var group__funciones__timer =
[
    [ "vTimerRTCCallback", "group__funciones__timer.html#gad33ed93210a4159478c3e2725bb67af2", null ],
    [ "vTimerSistemaActivoCallback", "group__funciones__timer.html#gaf978668233e008008442216fb540f883", null ]
];