var group___tareas =
[
    [ "vTaskSleepManager", "group___tareas.html#ga037292a7783146e25a2cd73b729ad658", null ],
    [ "vTaskTelegramHandler", "group___tareas.html#gab36e68f65275da880ec38864663dadb9", null ]
];