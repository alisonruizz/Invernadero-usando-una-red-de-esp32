var annotated_dup =
[
    [ "struct_actuador", "structstruct__actuador.html", "structstruct__actuador" ],
    [ "struct_rtc", "structstruct__rtc.html", "structstruct__rtc" ],
    [ "struct_sync", "structstruct__sync.html", "structstruct__sync" ]
];