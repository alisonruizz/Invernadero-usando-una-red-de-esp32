var structstruct__actuador =
[
    [ "comando", "structstruct__actuador.html#a9539e74aa5f87df5e313a7e752b9a6bb", null ],
    [ "temperatura", "structstruct__actuador.html#ac1b53f685e13112e8667bc1340ebae33", null ]
];