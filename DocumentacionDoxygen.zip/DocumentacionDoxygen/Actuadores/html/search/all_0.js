var searchData=
[
  ['comando_0',['comando',['../structstruct__actuador.html#a9539e74aa5f87df5e313a7e752b9a6bb',1,'struct_actuador::comando'],['../structstruct__sync.html#a809560142ed7aa6a79e5886ce9521d96',1,'struct_sync::comando']]]
];
