var searchData=
[
  ['temperatura_0',['temperatura',['../structstruct__actuador.html#ac1b53f685e13112e8667bc1340ebae33',1,'struct_actuador']]],
  ['timestamp_1',['timestamp',['../structstruct__sync.html#ad8b7f51c1a30cd4b495179d571b55f55',1,'struct_sync']]]
];
