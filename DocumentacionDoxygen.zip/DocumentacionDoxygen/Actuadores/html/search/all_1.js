var searchData=
[
  ['hora_0',['hora',['../structstruct__rtc.html#aeea0f315d51983c1da3a91f9cbd7379d',1,'struct_rtc']]]
];
