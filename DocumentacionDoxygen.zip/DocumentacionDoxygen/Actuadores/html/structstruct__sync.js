var structstruct__sync =
[
    [ "comando", "structstruct__sync.html#a809560142ed7aa6a79e5886ce9521d96", null ],
    [ "timestamp", "structstruct__sync.html#ad8b7f51c1a30cd4b495179d571b55f55", null ]
];