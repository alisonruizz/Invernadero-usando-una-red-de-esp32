var structstruct__rtc =
[
    [ "hora", "structstruct__rtc.html#aeea0f315d51983c1da3a91f9cbd7379d", null ]
];