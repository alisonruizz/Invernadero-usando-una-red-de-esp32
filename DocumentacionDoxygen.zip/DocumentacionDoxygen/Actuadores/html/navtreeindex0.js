var NAVTREEINDEX0 =
{
"annotated.html":[0,0],
"classes.html":[0,1],
"functions.html":[0,2,0],
"functions_vars.html":[0,2,1],
"index.html":[],
"pages.html":[],
"structstruct__actuador.html":[0,0,0],
"structstruct__actuador.html#a9539e74aa5f87df5e313a7e752b9a6bb":[0,0,0,0],
"structstruct__actuador.html#ac1b53f685e13112e8667bc1340ebae33":[0,0,0,1],
"structstruct__rtc.html":[0,0,1],
"structstruct__rtc.html#aeea0f315d51983c1da3a91f9cbd7379d":[0,0,1,0],
"structstruct__sync.html":[0,0,2],
"structstruct__sync.html#a809560142ed7aa6a79e5886ce9521d96":[0,0,2,0],
"structstruct__sync.html#ad8b7f51c1a30cd4b495179d571b55f55":[0,0,2,1]
};
