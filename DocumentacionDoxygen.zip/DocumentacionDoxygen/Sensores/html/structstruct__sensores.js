var structstruct__sensores =
[
    [ "hum_dht", "structstruct__sensores.html#a71f9e452063d05036b000cfc5bc05188", null ],
    [ "luz", "structstruct__sensores.html#a27390b7123fa2c71cd91cfb6d8bfbcb0", null ],
    [ "temp_dht", "structstruct__sensores.html#a0cde7f102362f1812daa3869a8799414", null ],
    [ "temp_ds18b20", "structstruct__sensores.html#aa24e60032001a219be9567b2ec80be28", null ]
];