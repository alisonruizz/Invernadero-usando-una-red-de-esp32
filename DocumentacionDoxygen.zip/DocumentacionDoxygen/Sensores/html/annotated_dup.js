var annotated_dup =
[
    [ "struct_rtc", "structstruct__rtc.html", "structstruct__rtc" ],
    [ "struct_sensores", "structstruct__sensores.html", "structstruct__sensores" ],
    [ "struct_sync", "structstruct__sync.html", "structstruct__sync" ]
];