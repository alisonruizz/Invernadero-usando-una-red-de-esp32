var searchData=
[
  ['struct_5frtc_0',['struct_rtc',['../structstruct__rtc.html',1,'']]],
  ['struct_5fsensores_1',['struct_sensores',['../structstruct__sensores.html',1,'']]],
  ['struct_5fsync_2',['struct_sync',['../structstruct__sync.html',1,'']]]
];
