var searchData=
[
  ['temp_5fdht_0',['temp_dht',['../structstruct__sensores.html#a0cde7f102362f1812daa3869a8799414',1,'struct_sensores']]],
  ['temp_5fds18b20_1',['temp_ds18b20',['../structstruct__sensores.html#aa24e60032001a219be9567b2ec80be28',1,'struct_sensores']]],
  ['timestamp_2',['timestamp',['../structstruct__sync.html#ad8b7f51c1a30cd4b495179d571b55f55',1,'struct_sync']]]
];
