var searchData=
[
  ['luz_0',['luz',['../structstruct__sensores.html#a27390b7123fa2c71cd91cfb6d8bfbcb0',1,'struct_sensores']]]
];
