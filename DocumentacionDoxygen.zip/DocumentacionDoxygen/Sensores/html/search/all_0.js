var searchData=
[
  ['comando_0',['comando',['../structstruct__sync.html#a809560142ed7aa6a79e5886ce9521d96',1,'struct_sync']]]
];
