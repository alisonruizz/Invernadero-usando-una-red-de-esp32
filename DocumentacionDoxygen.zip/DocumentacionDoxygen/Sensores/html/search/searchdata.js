var indexSectionsWithContent =
{
  0: "chlst",
  1: "s",
  2: "chlt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Variables"
};

